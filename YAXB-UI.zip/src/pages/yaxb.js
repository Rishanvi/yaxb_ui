import React from "react";
import Meta from "./../components/Meta";
import AIKiosk from "../components/yaxb/AIKiosk";

function YaxbPage(props) {
  return (
    <>
      <Meta />
      <AIKiosk
        bg="white"
        textColor="dark"
        size="sm"
        bgImage=""
        bgImageOpacity={1}
      />
    </>
  );
}

export default YaxbPage;
