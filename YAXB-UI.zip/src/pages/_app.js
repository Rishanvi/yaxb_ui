import React from "react";
import "./../styles/global.scss";
import NavbarCustom from "./../components/NavbarCustom";
import IndexPage from "./index";
import { Switch, Route, Router } from "./../util/router";
import NotFoundPage from "./404";
import Footer from "./../components/Footer";

import YaxbPage from "./yaxb";
import CuratePage from "./curate";


function App(props) {

  
  return (

    <Router>
      <>
        <NavbarCustom
          bg="white"
          variant="light"
          expand="md"
          logo="/LoopTech_MockupLogo_Black_15MAY2023.png"
        />

        <Switch>
          <Route exact path="/" component={IndexPage} />
          <Route exact path="/yaxb" component={YaxbPage} />
          <Route exact path="/curate" component={CuratePage} />

          <Route component={NotFoundPage} />
        </Switch>

        <Footer
          bg="white"
          textColor="dark"
          size="md"
          bgImage=""
          bgImageOpacity={1}
          copyright={`© ${new Date().getFullYear()} Company`}
          logo="/LoopTech_MockupLogo_Black_15MAY2023.png"
        />
      </>
    </Router>
  );
}

export default App;
