import React from "react";
import Meta from "../components/Meta";
import TimeLine from "../components/yaxb/curate/TimeLine";

function CuratePage(props) {


  return (
    <>
      <Meta />
      <TimeLine
        bg="white"
        textColor="dark"
        size="sm"
        bgImage=""
        bgImageOpacity={1}
      />
    </>
  );
}

export default CuratePage;
