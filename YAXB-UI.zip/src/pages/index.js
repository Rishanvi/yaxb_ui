import React from "react";
import Meta from "./../components/Meta";
import PlaylistSection from "./../components/PlaylistSection";

function IndexPage(props) {
  return (
    <>
      <Meta />
      <PlaylistSection
        bg="white"
        textColor="dark"
        size="sm"
        bgImage=""
        bgImageOpacity={1}
      />
    </>
  );
}

export default IndexPage;
