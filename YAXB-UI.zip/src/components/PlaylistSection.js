import React,{ useState,useRef } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Jumbotron from "react-bootstrap/Jumbotron";
import Button from "react-bootstrap/Button";
import { LinkContainer } from "react-router-bootstrap";
import Section from "./Section";
import CarouselSection from "./CarouselSection";
import SectionHeader from "./SectionHeader";
import ModalLauncher from "./ModalLauncher";
import "./PlaylistSection.scss";

function PlaylistSection(props) {

  const hr_items = [
    {
      title: "Global Policy Manual",
      description:
        "Our Code will help you understand the commitments we have made as a company and the expectations we set for all LoopTech employees. ",
      iconClass: "fas fa-globe",
      iconColor: "primary",
      baselinedate: "Apr '24",
    },
    {
      title: "Hourly Employee Manual",
      description:
        "This manual provides an overview of LoopTech’s employment and workplace policies for employees categorized as ‘Hourly’. ",
      iconClass: "fas fa-clock",
      iconColor: "primary",
      baselinedate: "Apr '24",
    },
    {
      title: "Salaried Employee Manual",
      description:
        "This manual provides an overview of LoopTech’s employment and workplace policies for employees categorized as ‘salary’.",
      iconClass: "fas fa-wallet",
      iconColor: "primary",
      baselinedate: "Apr '24",
    },
  ];

  var notFound = [{
    title: "No documents found",
    description:
    "We assure the safety of the documents uploaded",
  iconClass: "fas fa-lock",
  iconColor: "primary",
}];

  //0,1,2,3 for selected item
  var item_array = [notFound,hr_items,notFound,notFound,notFound];

  const [items,setItems] = useState(hr_items);

  function setItemValue()
  {
    setItems(item_array[document.getElementById("inputGroupSelect01").value])
  }
  

  

  return (

    <Section
      bg={props.bg}
      textColor={props.textColor}
      size={props.size}
      bgImage={props.bgImage}
      bgImageOpacity={props.bgImageOpacity}
    >
      <Container>
      <Jumbotron>
              <h1>Hello There !</h1>
              <Row className="align-items-center">
          <Col lg={10} className="text-center text-lg-left">
              <p>Our aim is to make AI accessible to everyone, so we created this Self-Managed AI environment exclusively for you. 
                Your documents, data, context grounding and inference logic is private, safe and secure, to this - the sandbox environment 
                provides ring fenced storage and marks the territory with your exclusive provenance label preventing any unauthorised access.
                
                </p>
                </Col>
                <Col lg={2} className="text-center text-lg-left">
                  <a href="/yaxb">
                    <Button
                      variant="primary"
                      size="lg"
                      block={true}
                    >
                      Explore
                    </Button>
                  </a>
                </Col>
                </Row>
            </Jumbotron>
        <Row className="align-items-center">
          <Col lg={6} className="text-center text-lg-left">

            <figure className="PlaylistSection__image-container mx-auto">
              <CarouselSection
                items={[
                  {
                    image:
                      "/Cook_Bloomington.png",
                    caption: "Bloomington Headquarters",
                  },
                  {
                    image:
                      "/Cook_Components_vert.png",
                    caption: "LoopTech products",
                  },
                  {
                    image:
                      "/West_bidane_hotel.png",
                    caption: "West Bidane Hotel",
                  },
                ]}
              />
            </figure>
          </Col>
          <Col className="offset-lg-1 mt-5 mt-lg-0 ">
            {items.map((item, index) => (
              <Row className="py-4 align-items-center" key={index}>
                <Col xs="auto">
                  <div
                    className={`PlaylistSection__icon text-${item.iconColor} d-inline-flex justify-content-center`}
                  >
                    <i className={`${item.iconClass}`} />
                  </div>
                </Col>
                <Col sx="auto" className="pl-4">
                  <SectionHeader
                    title={item.title}
                    subtitle={item.description}
                    baselinedate={item.baselinedate}
                    size={5}
                    spaced={false}
                    className="mb-0"
                  />
                </Col>
              </Row>
            ))}
          </Col>
        </Row>
        <Row>
          <Col > 
          <div className="input-group mb-3">
            <div className="input-group-prepend">
              <label className="input-group-text" htmlFor="inputGroupSelect01">Department</label>
            </div>
            <select className="custom-select" id="inputGroupSelect01" defaultValue="1" onChange={() => setItemValue()}>
              <option value="0">Choose...</option>
              <option value="1">Human Resources</option>
              <option value="2">Products Brochures</option>
              <option value="3">Clinical Trials</option>
              <option value="3">Research and Development</option>              
            </select>
          </div>
          </Col>
          <Col>
            <LinkContainer to={`#`}>
              <Button
                variant="primary"
                size="lg"
                block={true}
                className="mt-auto"
              >
                Add Document
              </Button>
            </LinkContainer>
          </Col>
        </Row>
      </Container>
    </Section>
  );
}

export default PlaylistSection;
