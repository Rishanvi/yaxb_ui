import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import NewsletterSection from "./NewsletterSection";
import sampleresponse from "./sampleresponse";
import ResponseSection from "./ResponseSection";
import "./ModalLauncher.scss";
import { HfInference } from '@huggingface/inference'

function ModalLauncher(props) {
  const [show, setShow] = useState(false);
  const [data, setData] = useState(null);
  const openai = "sk-proj-iOFvYcIGvzQZ7WVr2ZXnT3B|bkFJ4fiDzabHO3kanG3PyWku"

  function TextToSpeech(s) {
    var sModelId = "tts-1-hd";
    var sVoiceId = "echo";
    var API_KEY = openai;


    var oHttp = new XMLHttpRequest();
    oHttp.open("POST", "https://api.openai.com/v1/audio/speech");
    oHttp.setRequestHeader("Accept", "audio/mpeg");
    oHttp.setRequestHeader("Content-Type", "application/json");
    oHttp.setRequestHeader("Authorization", "Bearer " + API_KEY);

    oHttp.onload = function () {
        if (oHttp.readyState === 4) {


            var oBlob = new Blob([this.response], { "type": "audio/mpeg" });
            var audioURL = window.URL.createObjectURL(oBlob);
            var audio = document.getElementById('yaxbagent');
            audio.src = audioURL;
            audio.play();
        }
    };

    oHttp.onerror = function () {

      console.log(">>>>>>>>>>>>>>>>>>>>>>>")
    }

    var data = {
        model: sModelId,
        input: s,
        voice: sVoiceId
    };

    oHttp.responseType = "arraybuffer";
    oHttp.send(JSON.stringify(data));
}  
  function fetchAPI() {
    // param is a highlighted word from the user before it clicked the button
    fetch("http://127.0.0.1:5110/api/prompt_route?&user_prompt=" + document.getElementById("searchInput").value).then(response => setData(response))
    //.then(json => setData(json))
    .catch(error => console.error(error));
    //console.log(data);
  }

  function handleClick() {

//    var s = " The data privacy policy provided in the context outlines the guidelines and procedures for handling personal data within LoopTech, a company that operates in various industries such as hotels, employment, and healthcare. The policy emphasizes the importance of respecting the privacy of employees, customers, patients, and business partners."
//    TextToSpeech(s);

//    return;

    const xhr = new XMLHttpRequest();
    console.log("herererererrerererherere");
    let data22 = JSON.stringify(
        {
          'query':document.getElementById("searchInput").value,
          'queryingtech':'normal',
          'retrievingtech':'colbert2'
        });
    xhr.open('POST', 'http://13.234.19.201:8505', true);

    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = () => {
      if (xhr.readyState == 4 && xhr.status == 200) {

        console.log("******SSUCCESS*********");
        setData(JSON.parse(xhr.responseText));
/*        if(data && data["response"])
        {
          console.log("comee for speech recg..");
          var s = " The data privacy policy provided in the context outlines the guidelines and procedures for handling personal data within LoopTech, a company that operates in various industries such as hotels, employment, and healthcare. The policy emphasizes the importance of respecting the privacy of employees, customers, patients, and business partners."
          TextToSpeech(s);
        }*/
      } else {
        console.log("***"+xhr.readyState+"***ERROR****"+xhr.status+"*****");
      }
    };



    console.log(data22) ;
    xhr.send(data22);
  }


  

  return (
    <>
      <Button
        variant="primary"
        size="lg"
        block={true}
        onClick={() => setShow(true)}
      >
        Explore      </Button>
      <Modal
        show={show}
        onHide={() => setShow(false)}
        container={document.body}
        size="xl"
      >
        <Modal.Header closeButton={true}>
          <Modal.Title>Ask me...</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div class="search-2">
            <form
                id="promptForm"
                method="POST"
              >
                <input
                  type="text"
                  name="user_prompt"
                  id="searchInput"
                  placeholder="Tell me what you would want to know ?"
                />
                <button type="button" onClick={() => handleClick()} >
                  Ask YaXB 👩‍🎤
                </button>
              </form>


        </div>
             <div>

              {data && data["response"]}
             </div>

        </Modal.Body>
        <Modal.Footer>
          <audio id="yaxbagent" controls></audio>

          <a className="a_name btn_round" id="recordButton" href="#"><i className="fa fa-microphone"></i></a>

          <Button variant="secondary" size="md" onClick={() => setShow(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalLauncher;


/*<NewsletterSection
bg="white"
textColor="dark"
size="md"
bgImage=""
bgImageOpacity={1}
title="Stay in the know"
subtitle="Receive our latest articles and feature updates"
buttonText="Subscribe"
buttonColor="primary"
inputPlaceholder="Enter your email"
subscribedMessage="You are now subscribed!"
/>
*/