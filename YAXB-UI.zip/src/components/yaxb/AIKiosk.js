import React,{ useState,useRef } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Section from "./../Section";
import SectionHeader from "./../SectionHeader";
import MultiModalSection from "./MultiModalSection";
import ModelOutput from "./ModelOutput";

function AIKiosk(props) {

    return (

        <Section
            bg={props.bg}
            textColor={props.textColor}
            size={props.size}
            bgImage={props.bgImage}
            bgImageOpacity={props.bgImageOpacity}
        >
            <Container>
                <Row className="align-items-center">
                    <Col lg={8} className="text-center text-lg-left">
                        <MultiModalSection showNameField={true} buttonText="Ask"></MultiModalSection>
                    </Col>

                    <Col lg={4} className="text-center text-lg-left">
                        <ModelOutput></ModelOutput>
                    </Col>
                </Row>
            </Container>
        </Section>
    )
}

export default AIKiosk;


/*

<Row className="align-items-right">
            <Col className="text-right text-lg-right">
                <a href="/curate"><Button
                variant="primary"
                size="lg">
                    Moderate
            </Button></a>           
            <span>&nbsp;&nbsp;&nbsp;</span>

            <a href="/"><Button
                variant="primary"
                size="lg">
                    Close
            </Button></a>

            </Col>
            </Row>

            */