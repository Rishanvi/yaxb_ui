
function AnswerSection(props) {

    return (
        <>
            <div className="timeline-item clearfix">
                <div className="timeline-info">
                    <i className="timeline-indicator ace-icon fa fa-cutlery btn btn-success no-hover"></i>
                </div>

                <div className="widget-box transparent">
                    <div className="widget-body">
                        <div className="widget-main"> {props.data} </div>
                        <div className="pull-right">
                            <i className="ace-icon fa fa-clock"></i>
                            12:30
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AnswerSection;
