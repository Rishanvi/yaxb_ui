
function QuestionSection(props) {

    return (
    <>
        <div className="timeline-item clearfix">
        <div className="timeline-info">
            <i className="timeline-indicator ace-icon fa fa-bug btn btn-danger no-hover"></i>
        </div>

        <div className= {props.RedFlag ? "widget-box transparent" : "widget-box transparent"}>
            <div className="widget-header widget-header-small">
                <h5 className="widget-title smaller">
                    <a href="#" className="blue">Max P</a>
                    <span className="grey">reviewed a response</span>
                </h5>

                <span className="widget-toolbar no-border">
                    <i className="ace-icon fa fa-clock-o bigger-110"></i>
                    16:22
                </span>

                <span className="widget-toolbar">
                    <a href="#" data-action="reload">
                        <i className="ace-icon fa fa-refresh"></i>
                    </a>

                    <a href="#" data-action="collapse">
                        <i className="ace-icon fa fa-chevron-up"></i>
                    </a>
                </span>
            </div>

            <div className="widget-body">
                <div className="widget-main">
                    {props.data}...
                    <div className="space-6"></div>

                    <div className="widget-toolbox clearfix">
                        <div className="pull-left">
                            <i className="ace-icon fa fa-hand-o-right grey bigger-125"></i>
                            <a href="#" className="bigger-110">Click to read …</a>
                        </div>

                        <div className="pull-right action-buttons"> 
                            <a href="#">
                                <i className="ace-icon fa fa-check green bigger-130"></i>
                            </a>

                            <a href="#">
                                <i className="ace-icon fa fa-pencil blue bigger-125"></i>
                            </a>

                            <a href="#">
                                <i className="ace-icon fa fa-times red bigger-125"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </>
    )
}

export default QuestionSection;
