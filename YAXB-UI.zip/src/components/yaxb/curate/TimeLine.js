import React,{ useState,useRef } from "react";

import QuestionSection from "./QuestionSection";
import AnswerSection from "./AnswerSection";
import "./TimeLine.scss";
import qa from "../sampleQA";

function TimeLine(props) {

    const [items,setItems] = useState(qa.slice(1,4));


    return (
        <>
            <div className="container">
                <div id="timeline-1" className="">
                    <div className="row">
                        <div className="col-xs-12 col-sm-10 col-sm-offset-1">
                            <div className="timeline-container">
                                <div className="timeline-label">
                                    <span className="label label-primary arrowed-in-right label-lg">
                                        <b>Today</b>
                                    </span>
                                    <div className="pull-right">
                                    <a href="/yaxb"><button>Close</button></a>
                                </div>
                                </div>
                                {items.map((item, index) => (
                                <div className="timeline-items" key={index}>
                                    <QuestionSection data={item["Question"]} redflag={item["RedFlag"]}></QuestionSection>
                                    <AnswerSection data={item["Answer"]}></AnswerSection>                                    
                                </div> 
                                  ))}
                                <div className="pull-right">
                                    <a href="/yaxb"><button>Close</button></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    );
}

export default TimeLine;
