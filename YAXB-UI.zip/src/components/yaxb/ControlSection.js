import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Spinner from "react-bootstrap/Spinner";
import Col from "react-bootstrap/Col";
import { useForm } from "react-hook-form";
import FormAlert from "./../FormAlert";
import FormField from "./../FormField";
import kioskcontrols from "./../../util/kioskcontrols"; 
import qa from "./sampleQA";


function ControlSection(props) {
  const [pending, setPending] = useState(false);
  const [formAlert, setFormAlert] = useState(null);
  const { handleSubmit, register, errors, reset } = useForm();
  const [items,setItems] = useState(qa.slice(8,9));
  const [data, setData] = useState(null);

  const getresponse = (state,status,responsetext) => {
    if (state == 4 && status == 200) {
      console.log("******SSUCCESS*********");
    }else{
      console.log("******SSUCCESS*********");
    }

  }

  const onSubmit = (data) => {

    // Show pending indicator
    setPending(true);

    kioskcontrols
      .submit(data,getresponse)
      .then((response) => {
        let promptresp = 'User: ' +data.user_prompt+ '\n' + 
              'Yaxb: '+ response['response'] + '\n' +
              document.getElementById('formPromptResponse').value ;
        // Clear form
        reset();
        document.getElementById('formPromptResponse').value=promptresp;
        // Show success alert message
        console.log(data);
        setFormAlert({
          type: "success",
          message: "Your message has been sent!",
        });
      })
      .catch((error) => {
        // Show error alert message
        setFormAlert({
          type: "error",
          message: error.message,
        });
      })
      .finally(() => {
        // Hide pending indicator
        setPending(false);
      });
  };

  return (
    <>
      {formAlert && (
        <FormAlert type={formAlert.type} message={formAlert.message} />
      )}

      <Form onSubmit={handleSubmit(onSubmit)}>
        <Form.Row>
          {props.showNameField && (
            <Form.Group as={Col} xs={12} sm={2} controlId="formName">
              <FormField
                size="md"
                name="name"
                type="label"
                placeholder="YAXB 🧞‍♀️"
                value="YAXB 🧞‍♀️"
                disabled
              />
            </Form.Group>
          )}

          <Form.Group
            as={Col}
            xs={12}
            sm={props.showNameField ? 8 : 12}
            controlId="formUser_Prompt"
          >
            <FormField
              size="md"
              name="user_prompt"
              type="text"
              placeholder="How may I help you ?"
              error={errors.user_prompt}
              inputRef={register({
                required: "Please enter what you wish for me to look out",
              })}
            />
          </Form.Group>
          <Form.Group
            as={Col}
            xs={12}
            sm={props.showNameField ? 2 : 12}
            controlId="formsubmit"
          >         
          <Button 
            variant={props.buttonColor}
            type="submit"
            disabled={pending}
            block={true}
          >
            <span>{props.buttonText}</span>

            {pending && (
              <Spinner
                animation="border"
                size="sm"
                role="status"
                aria-hidden={true}
                className="ml-2"
              >
                <span className="sr-only">Receiving...</span>
              </Spinner>
            )}
          </Button>
          </Form.Group>
        </Form.Row>
        <Form.Group controlId="formPromptResponse">
          <FormField
            size="xxl"
            name="promptresponse"
            type="textarea"
            placeholder="Let us explore"
            rows={15}
            value={data}
            disabled
          />
        </Form.Group>
      </Form>
    </>
  );
}

export default ControlSection;
