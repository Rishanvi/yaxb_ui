import React, { useState } from "react";
import Container from "react-bootstrap/Container";
import Section from "./../Section";
import SectionHeader from "./../SectionHeader";
import qa from "./sampleQA";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { Button } from "react-bootstrap";


function ModelOutput(props) {

    const [items,setItems] = useState(qa.slice(11,12));

    return (
        <Section
            bg={props.bg}
            textColor={props.textColor}
            size={props.size}
            bgImage={props.bgImage}
            bgImageOpacity={props.bgImageOpacity}
        >
            <Container className="text-center">
                <SectionHeader
                    title={props.title}
                    subtitle={props.subtitle}
                    size={2}
                    spaced={false}
                />

                <Row className="align-items-center">
                    <Col sx="auto" className="pl-4">
                        <audio controls></audio>
                    </Col>
                </Row>
                <Row className="align-items-center">
                    <Col sx="auto" className="pl-4">
                    <div className="card text-bg-info mb-3" style={{maxWidth: + '28rem;'}}>
                        <div className="card-header">
                            <h5 className="card-title">Censorship - LoopTech</h5>
                        </div>
                        <div className="card-body">
                            <p className="card-text">Michael Dosanje, Steven Carlos, Max Palladino.</p>
                        </div>
                        </div>
                    </Col>
                </Row>
                <Row className="align-items-center">
                <Col sx="auto" className="pl-4">
                <div className="card text-bg-info mb-3" style={{maxWidth: + '28rem;'}}>
                        <div className="card-header"> 
                         <h5 className="card-title">Curators - YAXB</h5>
                        </div>
                        <div className="card-body"> 
                            <p className="card-text">Ajay Singh, Tamil Selvan</p>
                        </div>
                        </div>
                    </Col>
                </Row>
                <Row className="align-items-center">
                <Col></Col>
                <Col>
                <a href="/curate"><Button>Moderate </Button></a>
                </Col>
                <Col>
                    <a href="/"><Button>Close</Button></a>
                    </Col>
                    <Col></Col>
                </Row>
            </Container>
        </Section>
    );
}

export default ModelOutput;