import React from "react";
import Container from "react-bootstrap/Container";
import Section from "./Section";
import SectionHeader from "./SectionHeader";
import Newsletter from "./Newsletter";
import "./NewsletterSection.scss";

function NewsletterSection(props) {
  return (
    <Section
      bg={props.bg}
      textColor={props.textColor}
      size={props.size}
      bgImage={props.bgImage}
      bgImageOpacity={props.bgImageOpacity}
    >
      <Container className="text-center">
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={2}
          spaced={false}
        />
        <div className="NewsletterSection__form-container mx-auto">
          <Newsletter
            buttonText={props.buttonText}
            buttonColor={props.buttonColor}
            inputPlaceholder={props.inputPlaceholder}
            subscribedMessage={props.subscribedMessage}
          />
        </div>
      </Container>
    </Section>
  );
}

export default NewsletterSection;
