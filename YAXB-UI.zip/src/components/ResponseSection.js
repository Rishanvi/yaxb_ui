import React,{ useState,useRef } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Section from "./Section";
import SectionHeader from "./SectionHeader";
import "./ResponseSection.scss";
import sampleresponse from "./sampleresponse";

function ResponseSection(props) {

  var jsonresp = JSON.parse(sampleresponse);
  var resp = jsonresp.Answer;
  var refer = jsonresp.Sources;

  var notFound = [{
    title: "No documents found",
    description:
    "We assure the safety of the documents uploaded",
  iconClass: "fas fa-lock",
  iconColor: "primary",
}];

function openNav() {
  console.log("here")

  document.getElementById("mySidepanel").style.width = "150px";
  document.getElementById("mySidepanel").hidden=false;
}

function closeNav() {
  console.log("here in close")
  document.getElementById("mySidepanel").style.width = "0";
  document.getElementById("mySidepanel").hidden=true;
}
  
function shorten(str, maxLen) {
  if (str.length <= maxLen) return str;
  const trimmed_str = str.replace(/ {1,}/g," ").trim();
  return trimmed_str.split(' ').splice(0, maxLen).join(' ');
}
  

  return (

    <Container>
    <Row className="align-items-center">
      {props.data}
    </Row>
  </Container>

  );
}

export default ResponseSection;


/*
          <Col lg={8} className="text-center text-lg-left">

            <figure className="PlaylistSection__image-container mx-auto">
              <div>
                <i>yaxb: </i>{resp}
              </div>
            </figure>
          </Col>
          */
/*
          <button className="openbtn" onClick={() => openNav()}>☰ Reference Documents</button>  
          <div id="mySidepanel" hidden className="sidepanel">
          <a href="#" className="closebtn" onClick={() => closeNav()}> ×</a>
            {refer.map((item, index) => (
                  <a href="#" key={index}>
                    {item[0]}
                  </a>
            ))}
          </div>*/