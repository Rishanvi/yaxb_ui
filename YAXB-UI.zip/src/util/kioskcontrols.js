import { apiRequestExternal } from "./util.js";

const endpoint = `http://13.234.19.201:8505`;

function submit(data) {
  let api_input={'query':data.user_prompt,'queryingtech':'normal','retrievingtech':'colbert2'};
  console.log(api_input);
  return apiRequestExternal(endpoint, "POST", 
    {'query':data.user_prompt,'queryingtech':'normal','retrievingtech':'colbert2'},
  );
}

function handleClick(question, callback) {

      const xhr = new XMLHttpRequest();
      console.log("herererererrerererherere");
      let data = JSON.stringify(
          {
            'query':question,
            'queryingtech':'normal',
            'retrievingtech':'colbert2'
          });
      xhr.open('POST', 'http://13.234.19.201:8505', true);
  
      xhr.setRequestHeader("Content-Type", "application/json");
  
      xhr.onreadystatechange = () => {
        if (xhr.readyState === 4 && xhr.status === 200) {
          console.log("******SSUCCESS*********");
          callback(xhr.readyState, xhr.status, xhr.responseText);
        } else {
          console.log("***"+xhr.readyState+"***ERROR****"+xhr.status+"*****");
        }
      };
  
      console.log(data) ;
      xhr.send(data);
    }
  

const kioskcontrols = { submit, handleClick };

export default kioskcontrols;
